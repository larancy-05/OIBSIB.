// script.js
document.addEventListener('DOMContentLoaded', () => {
    const display = document.getElementById('display');
    const buttons = Array.from(document.querySelectorAll('.btn'));
    const clearButton = document.getElementById('clear');
    const equalsButton = document.getElementById('equals');
    
    let currentInput = '';
    let operation = '';
    let firstOperand = '';

    buttons.forEach(button => {
        button.addEventListener('click', () => {
            const value = button.getAttribute('data-value');

            if (value === '/' || value === '*' || value === '-' || value === '+') {
                setOperation(value);
            } else {
                appendNumber(value);
            }
        });
    });

    clearButton.addEventListener('click', clearDisplay);
    equalsButton.addEventListener('click', calculate);

    function appendNumber(number) {
        if (operation === '=') {
            currentInput = number;
            operation = '';
        } else {
            currentInput += number;
        }
        updateDisplay();
    }

    function setOperation(op) {
        if (currentInput === '') return;

        if (firstOperand !== '') {
            calculate();
        }

        firstOperand = currentInput;
        currentInput = '';
        operation = op;
        updateDisplay();
    }

    function calculate() {
        if (firstOperand === '' || currentInput === '' || operation === '') return;

        let result;
        const num1 = parseFloat(firstOperand);
        const num2 = parseFloat(currentInput);

        switch (operation) {
            case '+':
                result = num1 + num2;
                break;
            case '-':
                result = num1 - num2;
                break;
            case '*':
                result = num1 * num2;
                break;
            case '/':
                result = num1 / num2;
                break;
            default:
                return;
        }

        currentInput = result.toString();
        operation = '=';
        firstOperand = '';
        updateDisplay();
    }

    function clearDisplay() {
        currentInput = '';
        operation = '';
        firstOperand = '';
        updateDisplay();
    }

    function updateDisplay() {
        display.textContent = currentInput || '0';
    }
});
