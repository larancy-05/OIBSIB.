# larancy princya basic to-do web app

A Pen created on CodePen.io. Original URL: [https://codepen.io/FLarancy-Princya/pen/vYoBVej](https://codepen.io/FLarancy-Princya/pen/vYoBVej).

